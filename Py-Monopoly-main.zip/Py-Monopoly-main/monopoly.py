import json
import tkinter as tk
import random
import math
from typing import Optional, List, Dict, Tuple, Any
import tkinter.messagebox as messagebox

# Try to import PIL for image handling in property cards overlay
try:
    from PIL import Image, ImageTk
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

#Introducing the class for the player(s) in the game
class Player():
    def __init__(self, name: str, color: str, starting_balance: int = 1500):
        self.name: str = name
        self.color: str = color
        self.location: int = 0
        self.balance: int = starting_balance
        self.properties: List['Property'] = []
        self.get_out_of_jail_card: bool = False
        self.in_jail: bool = False
        self.jail_turns: int = 0
        self.doubles_count: int = 0
        self.doubles_amount: int = 0
        self.has_rolled: bool = False
        self.selected_property: Optional['Property'] = None
        self.debt_amount: int = 0
        self.creditor: Optional['Player'] = None

    def move(self, steps):
        """Moves the player's location by the given number of steps.

        Args:
            steps (int): The number of steps to move the player.
        """
        
        newLocation = (self.location + steps) % 40 # There are 40 spaces on the board
        
        if newLocation < self.location and steps > 0:
            self.balance += 200  # Collect $200 for passing GO
            
        self.location = newLocation
        
    def moveToJail(self):
        """Moves the player to jail."""
        
        self.location = 10  # Jail is at position 10
        self.in_jail = True
        self.jail_turns = 0  # Reset jail turn counter
    
    def pay(self, amount, receiver=None):
        """Deducts the given amount from the player's balance.

        Args:
            amount (int): The amount to deduct from the player's balance.
            receiver (Player, optional): The player to receive the payment. Defaults to None.
        """
        
        self.balance -= amount #Paying money reduces player amount
        
        if receiver:
            receiver.collect(amount)
        
    def collect(self, amount, sender=None):
        """Adds the given amount to the player's balance.
        Args:
            amount (int): The amount to add to the player's balance.
            sender (Player, optional): The player sending the payment. Defaults to None.
        """
        
        self.balance += amount
        
        if sender:
            sender.pay(amount)

#Defining the properties in monopoly
class Property():
    def __init__(self, property_id: str, property_type: str, name: str, color: Optional[str], price: int, rent: Optional[List[int]], house_hotel_cost: Optional[int]):
        self.id: str = property_id
        self.type: str = property_type
        self.name: str = name
        self.color: Optional[str] = color
        self.price: int = price
        self.rent: Optional[List[int]] = rent
        self.house_hotel_cost: Optional[int] = house_hotel_cost
        
        self.location: int = -1
        self.owner: Optional['Player'] = None
        self.mortgaged: bool = False
        self.houses_and_hotels: int = 0
        
    def calculateRent(self, all_properties: List['Property'], dice_roll: int = 7) -> int:
        """Calculates the rent for the property based on its type and state.
        Args:
            all_properties (List[Property]): All properties in the game (needed for monopoly checks).
            dice_roll (int): The dice roll value (used for utilities). Defaults to 7.
            
        Returns:
            int: The calculated rent for the property.
        """
        
        # If mortgaged, no rent
        if self.mortgaged:
            return 0
        
        # Regular properties (colored)
        if self.type == 'property':
            # Check if owner has monopoly (all properties of same color)
            owner_has_monopoly = True
            for other_prop in all_properties:
                if other_prop.color == self.color and other_prop.owner != self.owner:
                    owner_has_monopoly = False
                    break
            
            # If there are buildings, use the rent for that level
            if self.houses_and_hotels > 0:
                return self.rent[self.houses_and_hotels]
            # If monopoly but no buildings, double the base rent
            elif owner_has_monopoly:
                return self.rent[0] * 2
            # Normal base rent
            else:
                return self.rent[0]
        
        # Railroads
        elif self.type == 'railroad':
            # Count how many railroads the owner has
            railroads_owned = sum(1 for p in all_properties if p.type == 'railroad' and p.owner == self.owner)
            # Rent: $25 for 1, $50 for 2, $100 for 3, $200 for 4
            return self.rent[railroads_owned - 1] if railroads_owned > 0 else 0
        
        # Utilities
        elif self.type == 'utility':
            # Count how many utilities the owner has
            utilities_owned = sum(1 for p in all_properties if p.type == 'utility' and p.owner == self.owner)
            # If owner has both utilities, multiply dice roll by 10; otherwise by 4
            multiplier = 10 if utilities_owned == 2 else 4
            return multiplier * dice_roll
        
        return 0
    
#Outlines what the cards are supposed to contain
class Card():
    def __init__(self, card_type: str, card_id: str, text: str, action: str):
        self.card_type: str = card_type
        self.card_id: str = card_id
        self.text: str = text
        self.action: str = action
        
    def runAction(self, player: 'Player', game: 'Monopoly'):
        """Runs the action associated with the card.
        
        Args:
            player: The player who drew the card
            game: The Monopoly game instance (needed for accessing game state)
        """
        
        action = self.action
        action_type = action['type']
        
        # Handle each card action type
        if action_type == "move":
            # Move to a specific location
            target_id = action['target']
            
            if target_id == "go":
                target_location = 0
            else:
                # Find the property by ID
                target_prop = game.getPropertyById(target_id)
                target_location = target_prop.location
            
            # Calculate steps and move
            if target_location < player.location:
                steps = 40 - player.location + target_location
            else:
                steps = target_location - player.location
                
            player.move(steps)
            game.handleLanding()
            
        elif action_type == "move_nearest":
            # Move to nearest railroad or utility
            group = action['group']
            rent_multiplier = action.get('rent_multiplier', 1)
            
            if group == "railroad":
                target_tiles = [t for t in game.tiles if t['type'] == 'property' and game.getPropertyById(t['property_id']).type == "railroad"]
            elif group == "utility":
                target_tiles = [t for t in game.tiles if t['type'] == 'property' and game.getPropertyById(t['property_id']).type == "utility"]
            
            # Find the nearest target tile (circular distance)
            min_distance = 40
            nearest_tile = None
            
            for t in target_tiles:
                # Calculate forward distance
                if t['position'] >= player.location:
                    distance = t['position'] - player.location
                else:
                    distance = 40 - player.location + t['position']
                
                if distance < min_distance:
                    min_distance = distance
                    nearest_tile = t
            
            # Move to nearest tile
            player.move(min_distance)
            
            # Handle rent multiplier for railroads and utilities
            if group == "railroad":
                game.handleLanding(rent_multiplier=rent_multiplier)
            elif group == "utility":
                # For utilities, rent is dice roll * multiplier
                dice1 = random.randint(1, 6)
                dice2 = random.randint(1, 6)
                total = dice1 + dice2
                game.handleLanding(rent_override=total * rent_multiplier)
                
        elif action_type == "move_relative":
            # Move relative number of spaces (can be negative)
            spaces = action['spaces']
            player.move(spaces)
            game.handleLanding()
            
        elif action_type == "add_funds":
            # Add money to player
            amount = action['amount']
            player.collect(amount)
            
        elif action_type == "remove_funds":
            # Remove money from player
            amount = action['amount']
            
            if player.balance >= amount:
                # Can pay
                player.pay(amount)
            else:
                # Cannot pay - set debt to bank
                player.pay(amount)
                player.debt_amount = abs(player.balance)
                player.balance = 0
                player.creditor = None  # Owes bank
                
                game.showMessage(
                    "Insufficient Funds",
                    f"{player.name} cannot pay ${amount}!\n\nYou must sell buildings and/or mortgage properties to pay ${player.debt_amount}.\n\nYou cannot end your turn until the debt is paid."
                )
            
        elif action_type == "get_out_of_jail_free":
            # Give player a get out of jail free card
            player.get_out_of_jail_card = True
            
        elif action_type == "go_to_jail":
            # Send player to jail
            player.moveToJail()
            game.showMessage("Go to Jail", f"{player.name} has been sent to jail!")
            
        elif action_type == "property_charges":
            # Charge per house and hotel
            house_cost = action['house_hotel_cost']
            hotel_cost = action['hotel_cost']
            
            total_charge = 0
            for prop in player.properties:
                if prop.type == "property":
                    if prop.houses_and_hotels == 5:  # Hotel
                        total_charge += hotel_cost
                    else:  # Houses
                        total_charge += house_cost * prop.houses_and_hotels
            
            if total_charge > 0:
                if player.balance >= total_charge:
                    # Can pay
                    player.pay(total_charge)
                    game.showMessage(
                        "Property Charges",
                        f"{player.name} paid ${total_charge} for property repairs."
                    )
                else:
                    # Cannot pay - set debt to bank
                    player.pay(total_charge)
                    player.debt_amount = abs(player.balance)
                    player.balance = 0
                    player.creditor = None  # Owes bank
                    
                    game.showMessage(
                        "Insufficient Funds",
                        f"{player.name} cannot pay ${total_charge} for property repairs!\n\nYou must sell buildings and/or mortgage properties to pay ${player.debt_amount}.\n\nYou cannot end your turn until the debt is paid."
                    )
            
        elif action_type == "pay_players":
            # Pay each other player
            amount = action['amount']
            total_payment = amount * (len(game.players) - 1)
            
            if player.balance >= total_payment:
                # Can pay all players
                for other_player in game.players:
                    if other_player != player:
                        player.pay(amount, other_player)
                
                game.showMessage(
                    "Payment to Players",
                    f"{player.name} paid ${amount} to each player (total: ${total_payment})."
                )
            else:
                # Pay as much as possible to each player
                for other_player in game.players:
                    if other_player != player:
                        player.pay(amount, other_player)
                player.pay(total_payment)
                player.debt_amount = abs(player.balance)
                player.balance = 0
                player.creditor = None  # Owes bank (simplified)
                
                game.showMessage(
                    "Insufficient Funds",
                    f"{player.name} cannot pay ${total_payment} to other players!\n\nYou must sell buildings and/or mortgage properties to pay ${player.debt_amount}.\n\nYou cannot end your turn until the debt is paid."
                )
            
        elif action_type == "collect_from_players":
            # Collect from each other player
            amount = action['amount']
            
            for other_player in game.players:
                if other_player != player:
                    if other_player.balance >= amount:
                        other_player.pay(amount, player)
                    else:
                        # Other player cannot pay - they go into debt
                        other_player.pay(amount, player)
                        other_player.debt_amount = abs(other_player.balance)
                        other_player.balance = 0
                        other_player.creditor = player
            
            total_collected = amount * (len(game.players) - 1)
            game.showMessage(
                "Collection from Players",
                f"{player.name} collected ${amount} from each player (total: ${total_collected})."
            )

#Defining the main class of Monopoly that contains all of the sub classes
class Monopoly():
    def __init__(self, pathToCards: str, options: Dict[str, Any] = {}):
        # Tkinter root window
        self.root: tk.Tk = tk.Tk()
        self.pathToCards = pathToCards
        self.options: Dict[str, Any] = options
        
        # Game state
        self.is_running: bool = False
        self.current_player_index: int = 0
        
        # Game data
        self.tiles: List[Dict[str, Any]] = []
        self.players: List[Player] = []
        self.properties: List[Property] = []
        self.chance_cards: List[Card] = []
        self.community_chest_cards: List[Card] = []
        
        # UI references (created dynamically)
        self.main_frame: Optional[tk.Frame] = None
        self.action_panel: Optional[tk.Frame] = None
        self.current_player_label: Optional[tk.Label] = None
        self.player_balance_label: Optional[tk.Label] = None
        self.player_position_label: Optional[tk.Label] = None
        self.dice_result_label: Optional[tk.Label] = None
        
        # Player creation UI (temporary)
        self.num_players: int = 2
        self.players_entry_frame: Optional[tk.Frame] = None
        self.player_name_entries: List[tk.Entry] = []
        self.player_colors: List[str] = []
        
        # Color mappings
        self.color_map: Dict[str, str] = {
            'brown': '#8B4513',
            'light_blue': '#87CEEB',
            'pink': '#FF1493',
            'orange': '#FFA500',
            'red': '#FF0000',
            'yellow': '#FFFF00',
            'green': '#00FF00',
            'dark_blue': '#0000CD'
        }
        
        self.available_colors: List[Tuple[str, str]] = [
            ('Red', '#E74C3C'),
            ('Blue', '#3498DB'),
            ('Green', '#27AE60'),
            ('Yellow', '#F1C40F'),
            ('Purple', '#9B59B6'),
            ('Orange', '#E67E22')
        ]
        
        self.extractDataFromJSON(pathToCards)
        
    def start(self):
        self.createMainMenu()
        self.root.mainloop()
        
    def extractDataFromJSON(self, pathToCards):
        """Extracts data from a JSON file to initialize cards and properties.

        Args:
            pathToCards (str): The path to the JSON file containing card and property data.
        """
        
        with open(pathToCards, 'r') as file:
            data = json.load(file)
            for properties in data['properties']:
                if properties['type'] == 'property':
                    newProperty = Property(
                        properties['id'],
                        properties['type'],
                        properties['name'],
                        properties['color'],
                        properties['price'],
                        [properties['rent'], *properties['rent_with_houses']],
                        properties['house_hotel_cost']
                    )
                elif properties['type'] == 'railroad':
                    newProperty = Property(
                        properties['id'],
                        properties['type'],
                        properties['name'],
                        None,
                        properties['price'],
                        [25, 50, 100, 200],
                        None
                    )
                elif properties['type'] == 'utility':
                    newProperty = Property(
                        properties['id'],
                        properties['type'],
                        properties['name'],
                        None,
                        properties['price'],
                        None,
                        None
                    )
                else:
                    continue  # Skip unknown property types
                self.properties.append(newProperty)
                
            for chance_cards in data['chance_cards']:
                newCard = Card(
                    'chance',
                    chance_cards['id'],
                    chance_cards['text'],
                    chance_cards['action']
                )
                self.chance_cards.append(newCard)
                
            for communityChestCards in data['community_chest_cards']:
                newCard = Card(
                    'community_chest',
                    communityChestCards['id'],
                    communityChestCards['text'],
                    communityChestCards['action']
                )
                self.community_chest_cards.append(newCard)
                
            for tile in data['board_spaces']:
                self.tiles.append(tile)
                
            # Assign locations to properties based on board tiles
            for tile in self.tiles:
                if tile['type'] == 'property' and 'property_id' in tile:
                    for prop in self.properties:
                        if prop.id == tile['property_id']:
                            prop.location = tile['position']
                            break
                        
            # Shuffle the chance and community chest cards
            random.shuffle(self.chance_cards)
            random.shuffle(self.community_chest_cards)

    def createMainMenu(self):
        """Creates the main menu screen"""
        
        # Clear current game screen
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Setting up the main window
        self.root.title("Monopoly Game | Main Menu")
        
        # Get screen dimensions and set to windowed fullscreen
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        self.root.geometry(f"{screen_width}x{screen_height}+0+0")
        self.root.state('zoomed')
        
        # Clear any existing widgets
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Main menu container
        menu_frame = tk.Frame(self.root, bg='#2C3E50')
        menu_frame.pack(fill='both', expand=True)
        
        # Title section
        title_frame = tk.Frame(menu_frame, bg='#2C3E50')
        title_frame.pack(pady=80)
        
        tk.Label(title_frame, text="MONOPOLY", font=('Segoe UI', 48, 'bold'), fg='#ECF0F1', bg='#2C3E50').pack()
        
        tk.Label(title_frame, text="Python Edition", font=('Segoe UI', 16), fg='#95A5A6', bg='#2C3E50').pack(pady=10)
        
        # Buttons frame
        buttons_frame = tk.Frame(menu_frame, bg='#2C3E50')
        buttons_frame.pack(pady=40)
        
        # Start Game Button
        if (self.is_running):
            start_btn = tk.Button(buttons_frame, text="Resume Game", font=('Segoe UI', 14, 'bold'), bg='#F1C40F', fg='white', width=25, height=2, command=self.createBoardScreen, cursor='hand2')
        else:
            start_btn = tk.Button(buttons_frame, text="Start Game", font=('Segoe UI', 14, 'bold'), bg='#27AE60', fg='white', width=25, height=2, command=self.showPlayerCreation, cursor='hand2')
        start_btn.pack(pady=10)
        
        # Game Rules Button
        rules_btn = tk.Button(buttons_frame, text="Game Rules", font=('Segoe UI', 14, 'bold'), bg='#9B59B6', fg='white', width=25, height=2, command=self.showRules, cursor='hand2')
        rules_btn.pack(pady=10)
        
        # Property Cards Button
        cards_btn = tk.Button(buttons_frame, text="View Property Cards", font=('Segoe UI', 14, 'bold'), bg='#3498DB', fg='white', width=25, height=2, command=self.showPropertyCardsOverlay, cursor='hand2')
        cards_btn.pack(pady=10)
        
        # Credits Button
        credits_btn = tk.Button(buttons_frame, text="Credits", font=('Segoe UI', 14, 'bold'), bg='#16A085', fg='white', width=25, height=2, command=self.showCredits, cursor='hand2')
        credits_btn.pack(pady=10)
        
        # Exit Button
        exit_btn = tk.Button(buttons_frame, text="Exit", font=('Segoe UI', 14, 'bold'), bg='#E74C3C', fg='white', width=25, height=2, command=self.root.quit, cursor='hand2')
        exit_btn.pack(pady=10)
        
        # Footer
        tk.Label(menu_frame, text="© 2025 Python Blockers - All Rights Reserved", font=('Segoe UI', 10), fg='#7F8C8D', bg='#2C3E50').pack(side='bottom', pady=20)
    
    def showPlayerCreation(self):
        """Shows the player creation screen with names and colors"""
        self.root.title("Monopoly Game | Player Creation")
        
        # Clear existing widgets
        for widget in self.root.winfo_children():
            widget.destroy()
        
        creation_frame = tk.Frame(self.root, bg='#34495E')
        creation_frame.pack(fill='both', expand=True)
        
        # Title
        tk.Label(creation_frame, text="Create Players", font=('Segoe UI', 32, 'bold'), fg='#ECF0F1', bg='#34495E').pack(pady=30)
        
        # Number of players selection
        num_players_frame = tk.Frame(creation_frame, bg='#34495E')
        num_players_frame.pack(pady=10)
        
        tk.Label(num_players_frame, text="Number of Players:", font=('Segoe UI', 12, 'bold'), fg='#ECF0F1', bg='#34495E').pack(side='left', padx=10)
        
        def on_spinbox_change():
            try:
                self.num_players = int(spinbox.get())
                self.updatePlayerEntries()
            except ValueError:
                pass
        
        spinbox = tk.Spinbox(num_players_frame, from_=2, to=6, font=('Segoe UI', 12), width=5, command=on_spinbox_change)
        spinbox.delete(0, 'end')
        spinbox.insert(0, str(self.num_players))
        spinbox.pack(side='left')
        
        # Frame for player entries
        self.players_entry_frame = tk.Frame(creation_frame, bg='#34495E')
        self.players_entry_frame.pack(fill='both', expand=True, padx=40, pady=20)
        
        # Store entry widgets
        self.player_name_entries = []
        self.player_colors = []
        
        # Create initial player entries
        self.updatePlayerEntries()
        
        # Buttons frame
        buttons_frame = tk.Frame(creation_frame, bg='#34495E')
        buttons_frame.pack(pady=20)
        
        tk.Button(buttons_frame, text="Start Playing", font=('Segoe UI', 12, 'bold'), bg='#27AE60', fg='white', width=20, height=2, command=self.startGame, cursor='hand2').pack(side='left', padx=10)
        
        tk.Button(buttons_frame, text="Back to Menu", font=('Segoe UI', 12, 'bold'), bg='#95A5A6', fg='white', width=20, height=2, command=self.createMainMenu, cursor='hand2').pack(side='left', padx=10)
    
    def updatePlayerEntries(self):
        """Updates the player entry fields based on number of players selected"""
        # Clear existing entries
        for widget in self.players_entry_frame.winfo_children():
            widget.destroy()
        
        self.player_name_entries = []
        self.player_colors = []
        
        # Dynamically calculate optimal columns to maximize space usage
        # Try to keep it as square as possible while fitting horizontally
        cols = min(self.num_players, math.ceil(math.sqrt(self.num_players * 1.5)))
        
        for i in range(self.num_players):
            row = i // cols
            col = i % cols
            
            # Player frame
            player_frame = tk.Frame(self.players_entry_frame, bg='#2C3E50', borderwidth=2, relief='groove')
            player_frame.grid(row=row, column=col, padx=10, pady=10, sticky='nsew')
            
            # Player number label
            tk.Label(player_frame, text=f"Player {i+1}", font=('Segoe UI', 14, 'bold'), fg='#ECF0F1', bg='#2C3E50').pack(pady=10)
            
            # Name entry
            name_frame = tk.Frame(player_frame, bg='#2C3E50')
            name_frame.pack(pady=5)
            
            tk.Label(name_frame, text="Name:", font=('Segoe UI', 11), fg='#ECF0F1', bg='#2C3E50').pack(side='left', padx=5)

            name_entry = tk.Entry(name_frame, font=('Segoe UI', 11), width=20)
            name_entry.insert(0, f"Player {i+1}")
            name_entry.pack(side='left', padx=5)
            self.player_name_entries.append(name_entry)
            
            # Color selection
            color_frame = tk.Frame(player_frame, bg='#2C3E50')
            color_frame.pack(pady=10, padx=5)
            
            tk.Label(color_frame, text="Color:", font=('Segoe UI', 11), fg='#ECF0F1', bg='#2C3E50').pack(pady=5)
            
            # Store default color as string
            default_color = self.available_colors[i % len(self.available_colors)][1]
            self.player_colors.append(default_color)
            
            # Color buttons in grid
            color_buttons_frame = tk.Frame(color_frame, bg='#2C3E50')
            color_buttons_frame.pack()
            
            # Create a StringVar for this specific player's radio button group
            # This keeps each player's radio buttons separate
            player_color_var = tk.StringVar(value=default_color)
            
            # Create radio button group with command callbacks
            def make_color_selector(index, color):
                def select_color():
                    self.player_colors[index] = color
                return select_color
            
            for idx, (color_name, color_code) in enumerate(self.available_colors):
                color_row = idx // 3
                color_col = idx % 3
                
                rb = tk.Radiobutton(
                    color_buttons_frame,
                    text="",
                    variable=player_color_var,
                    value=color_code,
                    bg=color_code,
                    width=3,
                    height=1,
                    selectcolor=color_code,
                    indicatoron=False,
                    activebackground=color_code,
                    cursor='hand2',
                    borderwidth=2,
                    relief='raised',
                    command=make_color_selector(i, color_code)
                )
                
                rb.grid(row=color_row, column=color_col, padx=3, pady=3)
        
        # Configure grid weights for even spacing and expansion
        for col in range(cols):
            self.players_entry_frame.grid_columnconfigure(col, weight=1, uniform="col")
        
        # Configure row weights for vertical expansion
        rows = math.ceil(self.num_players / cols)
        for row in range(rows):
            self.players_entry_frame.grid_rowconfigure(row, weight=1)
        
        # Update layout
        self.players_entry_frame.update_idletasks()
    
    def startGame(self):
        """Creates player objects from the entries and starts the game"""
        self.players = []
        
        for i in range(self.num_players):
            name = self.player_name_entries[i].get().strip()
            if not name:
                name = f"Player {i+1}"
            
            color = self.player_colors[i]
            
            player = Player(name, color, self.options.get('starting_balance', 1500))
            self.players.append(player)
        
        self.current_player_index = 0
        
        self.is_running = True
        
        self.createBoardScreen()
    
    def showRules(self):
        """Shows the game rules screen"""
        # Clear existing widgets
        for widget in self.root.winfo_children():
            widget.destroy()
        
        rules_frame = tk.Frame(self.root, bg='#34495E')
        rules_frame.pack(fill='both', expand=True)
        
        # Title
        tk.Label(rules_frame, text="Game Rules", font=('Segoe UI', 32, 'bold'), fg='#ECF0F1', bg='#34495E').pack(pady=30)
        
        # Rules text with scrollbar
        text_frame = tk.Frame(rules_frame, bg='#34495E')
        text_frame.pack(fill='both', expand=True, padx=40, pady=20)
        
        scrollbar = tk.Scrollbar(text_frame)
        scrollbar.pack(side='right', fill='y')
        
        rules_text = tk.Text(text_frame, font=('Segoe UI', 11), bg='#2C3E50', fg='#ECF0F1', wrap='word', yscrollcommand=scrollbar.set, padx=20, pady=20)
        rules_text.pack(side='left', fill='both', expand=True)
        scrollbar.config(command=rules_text.yview)
        
        rules_content = """
MONOPOLY RULES

OBJECT OF THE GAME:
To become the wealthiest player through buying, renting, and selling properties.

SETUP:
• Each player starts with $1,500
• All players start at GO
• Properties are unowned at the start

GAMEPLAY:
1. Roll the dice and move your token clockwise around the board
2. Follow the instructions for the space you land on
3. If you roll doubles, take another turn (but three doubles sends you to Jail!)

BUYING PROPERTY:
• When you land on an unowned property, you may buy it from the Bank
• If you don't buy it, the property is left unowned

PAYING RENT:
• When you land on a property owned by another player, pay rent to the owner
• Rent amount depends on the property and number of houses/hotels

HOUSES AND HOTELS:
• You must own all properties in a color group before building
• Maximum of 4 houses, then you can buy a hotel

MORTGAGING:
• Mortgage value is half the price of the property
• Unmortgage costs 10% interest on top of the mortgage value
• You cannot collect rent on mortgaged properties

JAIL:
• You go to Jail if you:
  - Land on "Go to Jail"
  - Roll doubles three times in a row
  - Draw a "Go to Jail" card
• Get out by:
  - Paying $50 before rolling
  - Rolling doubles on your turn
  - Using a "Get Out of Jail Free" card

BANKRUPTCY:
• If you owe more than you can pay, you're bankrupt
• Turn over all assets to creditor
• Last player remaining wins!

WINNING:
The game ends when all players but one have gone bankrupt.
        """
        
        rules_text.insert('1.0', rules_content)
        rules_text.config(state='disabled')
        
        # Back button
        tk.Button(rules_frame, text="Back to Menu", font=('Segoe UI', 12, 'bold'), bg='#95A5A6', fg='white', width=20, height=2, command=self.createMainMenu, cursor='hand2').pack(pady=20)
    
    def showCredits(self):
        """Shows the credits screen"""
        # Clear existing widgets
        for widget in self.root.winfo_children():
            widget.destroy()
        
        credits_frame = tk.Frame(self.root, bg='#34495E')
        credits_frame.pack(fill='both', expand=True)
        
        # Title
        tk.Label(credits_frame, text="Credits", font=('Segoe UI', 32, 'bold'), fg='#ECF0F1', bg='#34495E').pack(pady=30)
        
        # Credits content with scrollbar
        content_frame = tk.Frame(credits_frame, bg='#34495E')
        content_frame.pack(fill='both', expand=True, padx=40, pady=20)
        
        scrollbar = tk.Scrollbar(content_frame)
        scrollbar.pack(side='right', fill='y')
        
        credits_text = tk.Text(content_frame, font=('Segoe UI', 11), bg='#2C3E50', fg='#ECF0F1', wrap='word', yscrollcommand=scrollbar.set, padx=20, pady=20)
        credits_text.pack(side='left', fill='both', expand=True)
        scrollbar.config(command=credits_text.yview)
        
        credits_content = """
MONOPOLY - PYTHON EDITION

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

DEVELOPMENT TEAM

Project Lead & Lead Developer
    Python Blockers Team

Game Design & Implementation
    Core Game Logic
    Board Rendering System
    Property Management System
    Player Management System

User Interface Design
    Main Menu & Navigation
    Game Board Interface
    Action Panel System
    Victory Screen
    Property Cards Display - Designed by Inimi (https://github.com/InimicalPart)



━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

TECHNOLOGY STACK

Programming Language
    Python 3.13

Graphical User Interface
    Tkinter (Built-in GUI Library)

Image Processing (Optional)
    PIL/Pillow - Property Card Image Display

Data Management
    JSON - Game Data Storage

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SPECIAL FEATURES

✓ Dynamic Board Generation
✓ Multiplayer Support (2-6 Players)
✓ Property Trading System
✓ Building Management (Houses & Hotels)
✓ Mortgage System
✓ Chance & Community Chest Cards
✓ Jail Mechanics
✓ Bankruptcy Handling
✓ Victory Screen with Statistics
✓ Property Card Viewer
✓ Intuitive Action Panel

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

ACKNOWLEDGEMENTS

Original Monopoly Game
    © Hasbro, Inc.
    This is an educational project and is not affiliated with 
    or endorsed by Hasbro.

Inspiration
    Classic Monopoly Board Game
    Python Programming Community

Testing & Feedback
    Python Blockers Development Team
    Beta Testers & Community Contributors

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

VERSION INFORMATION

Version: 1.0.0
Release Date: December 2025
Platform: Windows, macOS, Linux

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Thank you for playing Monopoly - Python Edition!

For more information and updates, visit our repository.

© 2025 Python Blockers - All Rights Reserved
        """
        
        credits_text.insert('1.0', credits_content)
        credits_text.config(state='disabled')
        
        # Back button
        tk.Button(credits_frame, text="Back to Menu", font=('Segoe UI', 12, 'bold'), bg='#95A5A6', fg='white', width=20, height=2, command=self.createMainMenu, cursor='hand2').pack(pady=20)
    
    def showPropertyCardsOverlay(self):
        """Creates an overlay window to display all property cards with their images and details."""
        
        # Create a new top-level window
        overlay = tk.Toplevel(self.root)
        overlay.title("Property Cards")
        overlay.geometry("1200x800")
        overlay.configure(bg='#2C3E50')
        
        # Get screen dimensions and set to windowed fullscreen
        screen_width = overlay.winfo_screenwidth()
        screen_height = overlay.winfo_screenheight()
        overlay.geometry(f"{screen_width}x{screen_height}+0+0")
        overlay.state('zoomed')  # Maximize window (windowed fullscreen on Windows)
        
        # Create a canvas with scrollbar
        canvas = tk.Canvas(overlay, bg='#2C3E50', highlightthickness=0)
        scrollbar = tk.Scrollbar(overlay, orient="vertical", command=canvas.yview)
        scrollable_frame = tk.Frame(canvas, bg='#2C3E50')
        
        scrollable_frame.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        
        canvas.create_window((600, 0), window=scrollable_frame, anchor="n")
        canvas.configure(yscrollcommand=scrollbar.set)
        
        # Add title
        title_label = tk.Label(
            scrollable_frame, 
            text="MONOPOLY PROPERTY CARDS", 
            font=("Arial", 24, "bold"),
            bg='#2C3E50',
            fg='white'
        )
        title_label.pack(pady=20)
        
        # Add instruction label
        instruction_label = tk.Label(
            scrollable_frame,
            text="💡 Click on any card to toggle between normal and mortgaged versions",
            font=("Arial", 12, "italic"),
            bg='#2C3E50',
            fg='#F39C12'
        )
        instruction_label.pack(pady=(0, 10))
        
        # Get all properties
        property_cards = [p for p in self.properties if p.type == 'property']
        railroad_cards = [p for p in self.properties if p.type == 'railroad']
        utility_cards = [p for p in self.properties if p.type == 'utility']
        
        # Group properties by color
        groups = {}
        for prop in property_cards:
            if prop.color not in groups:
                groups[prop.color] = []
            groups[prop.color].append(prop)
        
        # Add railroads and utilities as groups
        if railroad_cards:
            groups['railroad'] = railroad_cards
        if utility_cards:
            groups['utility'] = utility_cards
        
        # Display properties by color group
        for group, props in groups.items():
            # Create a centered container for this color group
            group_container = tk.Frame(scrollable_frame, bg='#2C3E50')
            group_container.pack(pady=10)
            
            # group header
            color_frame = tk.Frame(group_container, bg='#34495E', padx=10, pady=10)
            color_frame.pack()
            
            # Determine display name for the group
            if group == 'railroad':
                display_name = 'RAILROADS'
            elif group == 'utility':
                display_name = 'UTILITIES'
            else:
                display_name = group.replace('_', ' ').upper()
            
            color_label = tk.Label(
                color_frame,
                text=display_name,
                font=("Arial", 16, "bold"),
                bg='#34495E',
                fg='white'
            )
            color_label.pack()
            
            # Properties in this color group
            props_container = tk.Frame(group_container, bg='#2C3E50')
            props_container.pack(pady=5)
            
            for idx, prop in enumerate(props):
                # Create a frame for each property card
                card_frame = tk.Frame(props_container, bg='white', relief='raised', borderwidth=2, cursor='hand2')
                card_frame.grid(row=0, column=idx, padx=10, pady=10, sticky='n')
                
                # Store toggle state for this card (False = normal, True = mortgaged)
                card_state = {'is_mortgaged_view': False}
                
                # Try to load the property image
                image_loaded = False
                if PIL_AVAILABLE:
                    try:
                        # Load both images
                        normal_img = Image.open(f"cards/property/{prop.id}.png")
                        # Convert to RGB to ensure proper bit depth handling (causes weird artifacts otherwise)
                        normal_img = normal_img.convert('RGB')
                        # Use consistent sizing for all cards - maintain aspect ratio
                        original_width, original_height = normal_img.size
                        aspect_ratio = original_width / original_height
                        target_height = 300
                        target_width = int(target_height * aspect_ratio)
                        
                        # Use LANCZOS for high-quality downsampling
                        normal_img = normal_img.resize((target_width, target_height), Image.Resampling.LANCZOS)
                        normal_photo = ImageTk.PhotoImage(normal_img)
                        
                        try:
                            mortgaged_img = Image.open(f"cards/mortgaged/{prop.id}.png")
                            # Convert to RGB to ensure proper bit depth handling
                            mortgaged_img = mortgaged_img.convert('RGB')
                            # Use same dimensions for mortgaged version
                            mortgaged_img = mortgaged_img.resize((target_width, target_height), Image.Resampling.LANCZOS)
                            mortgaged_photo = ImageTk.PhotoImage(mortgaged_img)
                        except:
                            mortgaged_photo = None
                        
                        img_label = tk.Label(card_frame, image=normal_photo, bg='white', cursor='hand2')
                        img_label.image = normal_photo
                        img_label.mortgaged_image = mortgaged_photo
                        img_label.normal_image = normal_photo
                        img_label.pack(pady=5, padx=5)
                        
                        # Toggle function
                        def toggle_card(event, label=img_label, state=card_state):
                            if label.mortgaged_image:
                                state['is_mortgaged_view'] = not state['is_mortgaged_view']
                                if state['is_mortgaged_view']:
                                    label.config(image=label.mortgaged_image)
                                else:
                                    label.config(image=label.normal_image)
                        
                        img_label.bind('<Button-1>', toggle_card)
                        image_loaded = True
                        
                    except Exception as e:
                        # If image can't be loaded, show property name instead
                        placeholder = tk.Label(
                            card_frame,
                            text=f"[{prop.name}]",
                            font=("Arial", 10),
                            bg='white',
                            width=20,
                            height=15
                        )
                        placeholder.pack(pady=5)
                else:
                    # PIL not available, show property name
                    placeholder = tk.Label(
                        card_frame,
                        text=f"[{prop.name}]",
                        font=("Arial", 10),
                        bg='white',
                        width=20,
                        height=15
                    )
                    placeholder.pack(pady=5)
                
                # Property details - only show if image didn't load
                if not image_loaded:
                    details_text = f"{prop.name}\n"
                    details_text += f"Price: ${prop.price}\n"
                    
                    if prop.type == 'property':
                        # Regular property with houses/hotels
                        details_text += f"Rent: ${prop.rent[0]}\n"
                        if len(prop.rent) > 1:
                            details_text += f"With 1 House: ${prop.rent[1]}\n"
                            details_text += f"With 2 Houses: ${prop.rent[2]}\n"
                            details_text += f"With 3 Houses: ${prop.rent[3]}\n"
                            details_text += f"With 4 Houses: ${prop.rent[4]}\n"
                            details_text += f"With Hotel: ${prop.rent[5]}\n"
                        details_text += f"House Cost: ${prop.house_hotel_cost}"
                    elif prop.type == 'railroad':
                        # Railroad
                        details_text += "Rent: $25 (1 owned)\n"
                        details_text += "Rent: $50 (2 owned)\n"
                        details_text += "Rent: $100 (3 owned)\n"
                        details_text += "Rent: $200 (4 owned)"
                    elif prop.type == 'utility':
                        # Utility
                        details_text += "Rent: 4x dice (1 owned)\n"
                        details_text += "Rent: 10x dice (2 owned)"
                    
                    details_label = tk.Label(
                        card_frame,
                        text=details_text,
                        font=("Arial", 8),
                        bg='white',
                        justify='left'
                    )
                    details_label.pack(pady=5, padx=5)
        
        # Pack canvas and scrollbar
        canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")
        
        # Mouse wheel scrolling - bind to overlay window so it works over all child widgets
        def scroll_overlay(event):
            canvas.yview_scroll(int(-1*(event.delta/120)), 'units')
        
        def bind_overlay_scroll(event):
            overlay.bind('<MouseWheel>', scroll_overlay)
        
        def unbind_overlay_scroll(event):
            overlay.unbind('<MouseWheel>')
        
        # Bind to the overlay window so it works over all child widgets (including cards)
        overlay.bind('<Enter>', bind_overlay_scroll)
        overlay.bind('<Leave>', unbind_overlay_scroll)
        
        # Add close button
        close_btn = tk.Button(
            overlay,
            text="Close",
            command=overlay.destroy,
            font=("Arial", 12),
            bg='#E74C3C',
            fg='white',
            padx=20,
            pady=10
        )
        close_btn.pack(side="bottom", pady=10)
    
    def showVictoryScreen(self, winner):
        """Display a victory screen when a player wins the game.
        
        Args:
            winner: The Player who won the game
        """
        # Clear the screen
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Create main victory frame
        victory_frame = tk.Frame(self.root, bg='#1a472a')
        victory_frame.pack(fill='both', expand=True)
        
        # Top spacing
        tk.Frame(victory_frame, bg='#1a472a', height=50).pack()
        
        # Trophy/Winner banner
        banner_frame = tk.Frame(victory_frame, bg='#FFD700', borderwidth=5, relief='ridge')
        banner_frame.pack(pady=20)
        
        tk.Label(
            banner_frame,
            text="🏆 VICTORY! 🏆",
            font=('Segoe UI', 48, 'bold'),
            bg='#FFD700',
            fg='#1a472a',
            padx=40,
            pady=20
        ).pack()
        
        # Winner name
        tk.Label(
            victory_frame,
            text=winner.name,
            font=('Segoe UI', 42, 'bold'),
            bg='#1a472a',
            fg=winner.color,
            pady=10
        ).pack()
        
        tk.Label(
            victory_frame,
            text="WINS THE GAME!",
            font=('Segoe UI', 32, 'bold'),
            bg='#1a472a',
            fg='#FFD700',
            pady=5
        ).pack()
        
        # Stats frame
        stats_frame = tk.Frame(victory_frame, bg='#2C3E50', borderwidth=3, relief='groove')
        stats_frame.pack(pady=30, padx=100)
        
        tk.Label(
            stats_frame,
            text="Final Statistics",
            font=('Segoe UI', 24, 'bold'),
            bg='#2C3E50',
            fg='#ECF0F1',
            pady=15
        ).pack()
        
        # Winner's balance
        tk.Label(
            stats_frame,
            text=f"Total Cash: ${winner.balance}",
            font=('Segoe UI', 18),
            bg='#2C3E50',
            fg='#2ECC71',
            pady=5
        ).pack()
        
        # Properties owned
        property_count = len(winner.properties)
        tk.Label(
            stats_frame,
            text=f"Properties Owned: {property_count}",
            font=('Segoe UI', 18),
            bg='#2C3E50',
            fg='#3498DB',
            pady=5
        ).pack()
        
        # Calculate total value of properties
        property_value = sum(p.price for p in winner.properties)
        tk.Label(
            stats_frame,
            text=f"Property Value: ${property_value}",
            font=('Segoe UI', 18),
            bg='#2C3E50',
            fg='#3498DB',
            pady=5
        ).pack()
        
        # Total net worth
        net_worth = winner.balance + property_value
        tk.Label(
            stats_frame,
            text=f"Total Net Worth: ${net_worth}",
            font=('Segoe UI', 20, 'bold'),
            bg='#2C3E50',
            fg='#F39C12',
            pady=10,
            padx=40
        ).pack()
        
        # Buttons frame
        button_frame = tk.Frame(victory_frame, bg='#1a472a')
        button_frame.pack(pady=30)
        
        # Play again button
        def play_again():
            # Reset game state
            self.is_running = False
            self.current_player_index = 0
            self.players = []
            
            # Re-extract data to reset properties and cards
            self.properties = []
            self.chance_cards = []
            self.community_chest_cards = []
            self.extractDataFromJSON(self.pathToCards)
            
            # Go back to main menu
            self.createMainMenu()
        
        tk.Button(
            button_frame,
            text="🎮 Play Again",
            font=('Segoe UI', 16, 'bold'),
            bg='#27AE60',
            fg='white',
            width=15,
            height=2,
            command=play_again,
            cursor='hand2'
        ).pack(side='left', padx=10)
        
        # Exit button
        tk.Button(
            button_frame,
            text="Exit Game",
            font=('Segoe UI', 16, 'bold'),
            bg='#E74C3C',
            fg='white',
            width=15,
            height=2,
            command=self.root.quit,
            cursor='hand2'
        ).pack(side='left', padx=10)
    
    def createBoardScreen(self):
        """Creates the main game screen with board and action panel"""
        self.root.title("Monopoly Game | In Game")
        
        # Clear and create game screen
        for widget in self.root.winfo_children():
            widget.destroy()
        
        # Main container
        container = tk.Frame(self.root, bg='white')
        container.pack(fill='both', expand=True, padx=5, pady=5)
        
        # Create a canvas with scrollbars for the board
        self.board_canvas = tk.Canvas(container, bg='white')
        self.board_canvas.pack(side='left', fill='both', expand=True)
        
        # Add scrollbars
        v_scrollbar = tk.Scrollbar(container, orient='vertical', command=self.board_canvas.yview)
        v_scrollbar.pack(side='left', fill='y', before=self.board_canvas)
        
        h_scrollbar = tk.Scrollbar(container, orient='horizontal', command=self.board_canvas.xview)
        h_scrollbar.pack(side='bottom', fill='x', before=self.board_canvas)
        
        self.board_canvas.configure(yscrollcommand=v_scrollbar.set, xscrollcommand=h_scrollbar.set)
        
        # Board frame (inside canvas)
        self.main_frame = tk.Frame(self.board_canvas, bg='white')
        self.board_canvas.create_window((0, 0), window=self.main_frame, anchor='nw')
        
        # Configure canvas scroll region after board is created
        def configure_scroll_region(event=None):
            self.board_canvas.configure(scrollregion=self.board_canvas.bbox('all'))
        
        self.main_frame.bind('<Configure>', configure_scroll_region)
        
        # Enable mousewheel scrolling for board
        def scroll_board(event):
            self.board_canvas.yview_scroll(int(-1*(event.delta/120)), 'units')
        
        def scroll_board_horizontal(event):
            self.board_canvas.xview_scroll(int(-1*(event.delta/120)), 'units')
        
        def bind_board_scroll(event):
            self.root.bind('<MouseWheel>', scroll_board)
            self.root.bind('<Shift-MouseWheel>', scroll_board_horizontal)
        
        def unbind_board_scroll(event):
            self.root.unbind('<MouseWheel>')
            self.root.unbind('<Shift-MouseWheel>')
        
        # Bind to the canvas so it works over all child widgets
        self.board_canvas.bind('<Enter>', bind_board_scroll)
        self.board_canvas.bind('<Leave>', unbind_board_scroll)
        
        # Action panel (right side)
        action_panel_container = tk.Frame(container, bg='#F0F0F0', width=300, borderwidth=2, relief='solid')
        action_panel_container.pack(side='right', fill='both', padx=(10, 0))
        action_panel_container.pack_propagate(False)
        
        # Create canvas and scrollbar for action panel
        action_canvas = tk.Canvas(action_panel_container, bg='#F0F0F0', highlightthickness=0)
        action_scrollbar = tk.Scrollbar(action_panel_container, orient='vertical', command=action_canvas.yview)
        
        self.action_panel = tk.Frame(action_canvas, bg='#F0F0F0')
        
        self.action_panel.bind(
            '<Configure>',
            lambda e: action_canvas.configure(scrollregion=action_canvas.bbox('all'))
        )
        
        # Center the action panel content
        action_canvas.create_window((150, 0), window=self.action_panel, anchor='n')
        action_canvas.configure(yscrollcommand=action_scrollbar.set)
        
        action_canvas.pack(side='left', fill='both', expand=True)
        action_scrollbar.pack(side='right', fill='y')
        
        # Store reference for scroll handling
        self.action_canvas = action_canvas
        self.action_panel_container = action_panel_container
        
        # Enable mousewheel scrolling for action panel
        def scroll_action_panel(event):
            action_canvas.yview_scroll(int(-1*(event.delta/120)), 'units')
        
        def bind_action_scroll(event):
            self.root.bind('<MouseWheel>', scroll_action_panel)
        
        def unbind_action_scroll(event):
            self.root.unbind('<MouseWheel>')
        
        # Bind to the container so it works over all child widgets
        action_panel_container.bind('<Enter>', bind_action_scroll)
        action_panel_container.bind('<Leave>', unbind_action_scroll)
        
        self.createActionPanel()
        self.updateBoard()
    
    def updateBoard(self):
        # Clear existing board
        for widget in self.main_frame.winfo_children():
            widget.destroy()
        
        for tile in self.tiles:
            x, y = self.convertPositionToCoordinates(tile['position'])
            
            # Get players at this position
            players_here = [p for p in self.players if p.location == tile['position']]
            
            if tile['type'] == 'go':
                tile_frame = tk.Frame(self.main_frame, borderwidth=2, relief="solid", bg='#90EE90')
                tile_frame.grid(column=x, row=y, sticky='nsew', padx=1, pady=1)
                
                label = tk.Label(tile_frame, text="GO\n$200", font=('Segoe UI', 10, 'bold'), fg='black', bg='#90EE90')
                label.pack(fill='x', pady=2)
                
            elif tile['type'] == 'property':
                property = self.getPropertyById(tile["property_id"])
                if property:
                    # Check if this property is selected by current player
                    current_player = self.players[self.current_player_index]
                    is_selected = (current_player.selected_property and current_player.selected_property.id == property.id)
                    
                    # Create a frame for the property with selection indicator
                    border_color = '#FFD700' if is_selected else 'black'  # Gold border if selected
                    border_width = 2 if is_selected else 1
                    tile_frame = tk.Frame(self.main_frame, borderwidth=border_width, relief="solid", bg='white', cursor='hand2', highlightbackground=border_color, highlightcolor=border_color, highlightthickness=border_width)
                    tile_frame.grid(column=x, row=y, sticky='nsew', padx=1, pady=1)
                    
                    # Make the entire tile clickable
                    tile_frame.bind('<Button-1>', lambda e, p=property: self._selectProperty(p))
                    
                    # Color bar at top if it's a colored property
                    if property.color:
                        color_bar = tk.Label(tile_frame, bg=self.color_map.get(property.color, 'white'), height=1, cursor='hand2')
                        color_bar.pack(fill='x')
                        color_bar.bind('<Button-1>', lambda e, p=property: self._selectProperty(p))
                    
                    # Houses/Hotels indicator (only for colored properties)
                    if property.color and property.houses_and_hotels > 0:
                        buildings_frame = tk.Frame(tile_frame, bg='white', cursor='hand2')
                        buildings_frame.pack(fill='x', pady=(2, 0))
                        buildings_frame.bind('<Button-1>', lambda e, p=property: self._selectProperty(p))
                        
                        if property.houses_and_hotels == 5:
                            # Hotel
                            hotel_label = tk.Label(buildings_frame, text="🏨", font=('Segoe UI', 8), bg='white', cursor='hand2')
                            hotel_label.pack()
                            hotel_label.bind('<Button-1>', lambda e, p=property: self._selectProperty(p))
                        else:
                            # Houses (1-4)
                            houses_text = "🏠" * property.houses_and_hotels
                            house_label = tk.Label(buildings_frame, text=houses_text, font=('Segoe UI', 7), bg='white', cursor='hand2')
                            house_label.pack()
                            house_label.bind('<Button-1>', lambda e, p=property: self._selectProperty(p))
                    
                    # Property name
                    name_label = tk.Label(tile_frame, text=property.name, font=('Segoe UI', 8), wraplength=80, justify='center', bg='white', fg='black', cursor='hand2')
                    name_label.pack(fill='x', pady=1)
                    name_label.bind('<Button-1>', lambda e, p=property: self._selectProperty(p))
                    
                    # Property price
                    price_label = tk.Label(tile_frame, text=f"${property.price}", font=('Segoe UI', 8, 'bold'), bg='white', fg='black', cursor='hand2')
                    price_label.pack(pady=(0, 1))
                    price_label.bind('<Button-1>', lambda e, p=property: self._selectProperty(p))
                    
                    # Ownership indicator at bottom
                    if property.owner:
                        owner_bar = tk.Label(tile_frame, bg=property.owner.color, height=1, cursor='hand2')
                        owner_bar.pack(side='bottom', fill='x')
                        owner_bar.bind('<Button-1>', lambda e, p=property: self._selectProperty(p))
                    
            elif tile['type'] == 'chance':
                tile_frame = tk.Frame(self.main_frame, borderwidth=2, relief="solid", bg='#FFB6C1')
                tile_frame.grid(column=x, row=y, sticky='nsew', padx=1, pady=1)
                
                label = tk.Label(tile_frame, text="CHANCE", font=('Segoe UI', 9, 'bold'), fg='black', bg='#FFB6C1')
                label.pack(fill='x', pady=2)
                
            elif tile['type'] == 'community_chest':
                tile_frame = tk.Frame(self.main_frame, borderwidth=2, relief="solid", bg='#ADD8E6')
                tile_frame.grid(column=x, row=y, sticky='nsew', padx=1, pady=1)
                
                label = tk.Label(tile_frame, text="COMM\nCHEST", font=('Segoe UI', 9, 'bold'), fg='black', bg='#ADD8E6')
                label.pack(fill='x', pady=2)
                
            elif tile['type'] == 'tax':
                tile_frame = tk.Frame(self.main_frame, borderwidth=2, relief="solid", bg='#F0E68C')
                tile_frame.grid(column=x, row=y, sticky='nsew', padx=1, pady=1)
                
                label = tk.Label(tile_frame, text=f"{tile['name']}\n${tile['amount']}", font=('Segoe UI', 9, 'bold'), fg='black', bg='#F0E68C')
                label.pack(fill='x', pady=2)
                
            elif tile['type'] == 'corner':
                # Special handling for Jail/Just Visiting corner
                if tile['position'] == 10:
                    tile_frame = tk.Frame(self.main_frame, borderwidth=2, relief="solid", bg='white')
                    tile_frame.grid(column=x, row=y, sticky='nsew', padx=1, pady=1)
                    
                    # Top half - Just Visiting
                    visiting_label = tk.Label(tile_frame, text="Just\nVisiting", font=('Segoe UI', 9, 'bold'), bg='#D3D3D3', fg='black', borderwidth=1, relief="solid")
                    visiting_label.pack(side='top', fill='both', expand=True)
                    
                    # Bottom half - Jail
                    jail_label = tk.Label(tile_frame, text="JAIL", font=('Segoe UI', 9, 'bold'), bg='#FFA500', fg='black', borderwidth=1, relief="solid")
                    jail_label.pack(side='bottom', fill='both', expand=True)
                else:
                    tile_frame = tk.Frame(self.main_frame, borderwidth=2, relief="solid", bg='#D3D3D3')
                    tile_frame.grid(column=x, row=y, sticky='nsew', padx=1, pady=1)
                    
                    label = tk.Label(tile_frame, text=tile['name'], font=('Segoe UI', 9, 'bold'), wraplength=80, fg='black', bg='#D3D3D3')
                    label.pack(fill='x', pady=2)
            
            # Player indicators (always reserve space) - applies to all tile types
            tile_bg = tile_frame.cget('bg')
            player_frame = tk.Frame(tile_frame, bg=tile_bg, height=18)
            player_frame.pack(side='bottom', fill='x')
            player_frame.pack_propagate(False)  # Always prevent propagation
            if players_here:
                for player in players_here:
                    player_dot = tk.Label(player_frame, text="●", font=('Segoe UI', 10), fg=player.color, bg=tile_bg)
                    player_dot.pack(side='left', padx=2)
        
        # Configure grid weights for equal sizing and scalability with minimum size
        for i in range(11):
            self.main_frame.grid_columnconfigure(i, weight=1, uniform="col", minsize=110)
            self.main_frame.grid_rowconfigure(i, weight=1, uniform="row", minsize=110)

    def createActionPanel(self):
        """Creates the action panel with player info and action buttons"""
        # Title
        title = tk.Label(self.action_panel, text="Game Controls", font=('Segoe UI', 14, 'bold'), bg='#F0F0F0')
        title.pack(pady=10)
        
        # Current Player Section
        player_frame = tk.Frame(self.action_panel, bg='#E0E0E0', borderwidth=2, relief='groove')
        player_frame.pack(fill='x', padx=10, pady=5)
        
        tk.Label(player_frame, text="Current Player:", font=('Segoe UI', 10, 'bold'), bg='#E0E0E0').pack(pady=5)
        
        self.current_player_label = tk.Label(player_frame, text="Player: N/A", font=('Segoe UI', 12, 'bold'), fg='#0066CC', bg='#E0E0E0')
        self.current_player_label.pack(pady=2)
        
        self.player_balance_label = tk.Label(player_frame, text="Balance: N/A", font=('Segoe UI', 10), bg='#E0E0E0')
        self.player_balance_label.pack(pady=2)
        
        self.player_position_label = tk.Label(player_frame, text="Position: N/A", font=('Segoe UI', 9), bg='#E0E0E0')
        self.player_position_label.pack(pady=(2, 8))
        
        # Dice Rolling Section
        dice_frame = tk.Frame(self.action_panel, bg='#F0F0F0')
        dice_frame.pack(fill='x', padx=10, pady=10)
        
        self.dice_btn = tk.Button(dice_frame, text="🎲 Roll Dice", font=('Segoe UI', 11, 'bold'), bg='#4CAF50', fg='white', command=self.rollDice, width=20, height=2)
        self.dice_btn.pack()
        
        self.dice_result_label = tk.Label(dice_frame, text="", font=('Segoe UI', 10), bg='#F0F0F0')
        self.dice_result_label.pack(pady=5)
        
        # Selected Property Card Display Section
        property_card_frame = tk.Frame(self.action_panel, bg='#E0E0E0', borderwidth=2, relief='groove')
        property_card_frame.pack(fill='x', padx=10, pady=10)
        
        tk.Label(property_card_frame, text="Selected Property", font=('Segoe UI', 10, 'bold'), bg='#E0E0E0').pack(pady=5)
        
        # Container for property card image
        self.property_card_container = tk.Frame(property_card_frame, bg='white', width=200, height=300)
        self.property_card_container.pack(pady=5, padx=5)
        self.property_card_container.pack_propagate(False)
        
        # Placeholder label
        self.property_card_label = tk.Label(self.property_card_container, text="Click a property\nto view its card", font=('Segoe UI', 10, 'italic'), bg='white', fg='#999999')
        self.property_card_label.pack(expand=True)
        
        # Property Actions Section
        tk.Label(self.action_panel, text="Property Actions", font=('Segoe UI', 11, 'bold'), bg='#F0F0F0').pack(pady=(10, 5))
        
        actions_frame = tk.Frame(self.action_panel, bg='#F0F0F0')
        actions_frame.pack(fill='x', padx=10)
        
        # Row 1: Buy Property
        property_buy_sell_row = tk.Frame(actions_frame, bg='#F0F0F0')
        property_buy_sell_row.pack(fill='x', pady=3)
        
        self.buy_property_btn = tk.Button(property_buy_sell_row, text="Buy Property", font=('Segoe UI', 9), bg='#CCCCCC', fg='#666666', command=self.buyProperty, width=12, state='disabled', disabledforeground='#666666')
        self.buy_property_btn.pack(side='left', expand=True, fill='x', padx=(0, 2))
        
        # Row 2: Buy/Sell Building (dynamic based on selected property)
        property_actions = tk.Frame(actions_frame, bg='#F0F0F0')
        property_actions.pack(fill='x', pady=3)
        
        self.buy_building_btn = tk.Button(property_actions, text="Buy House", font=('Segoe UI', 9), bg='#CCCCCC', fg='#666666', command=self.buyBuilding, width=12, state='disabled', disabledforeground='#666666')
        self.buy_building_btn.pack(side='left', expand=True, fill='x', padx=(0, 2))
        
        self.sell_building_btn = tk.Button(property_actions, text="Sell Building", font=('Segoe UI', 9), bg='#CCCCCC', fg='#666666', command=self.sellBuilding, width=12, state='disabled', disabledforeground='#666666')
        self.sell_building_btn.pack(side='left', expand=True, fill='x', padx=(2, 0))
        
        # Row 3: Mortgage and Unmortgage
        mortgage_row = tk.Frame(actions_frame, bg='#F0F0F0')
        mortgage_row.pack(fill='x', pady=3)
        
        self.mortgage_btn = tk.Button(mortgage_row, text="Mortgage", font=('Segoe UI', 9), bg='#CCCCCC', fg='#666666', command=self.mortgageProperty, width=12, state='disabled', disabledforeground='#666666')
        self.mortgage_btn.pack(side='left', expand=True, fill='x', padx=(0, 2))
        
        self.unmortgage_btn = tk.Button(mortgage_row, text="Unmortgage", font=('Segoe UI', 9), bg='#CCCCCC', fg='#666666', command=self.unmortgageProperty, width=12, state='disabled', disabledforeground='#666666')
        self.unmortgage_btn.pack(side='left', expand=True, fill='x', padx=(2, 0))
        
        # Get Out of Jail Button (handles both card and paying)
        self.jail_btn = tk.Button(actions_frame, text="Get Out of Jail", font=('Segoe UI', 9), bg='#CCCCCC', fg='#666666', command=self.getOutOfJail, width=25, state='disabled', disabledforeground='#666666')
        self.jail_btn.pack(fill='x', pady=(3, 0))
        
        # End Turn Button
        tk.Button(self.action_panel, text="End Turn", font=('Segoe UI', 10, 'bold'), bg='#F44336', fg='white', command=self.endTurn, width=25, height=2).pack(pady=20)
        
        # TEST: Win Game Button (for testing victory screen) - only in debug mode
        if self.options.get('debug_mode', False):
            tk.Button(self.action_panel, text="🏆 TEST WIN", font=('Segoe UI', 9, 'bold'), bg='#FFD700', fg='#1a472a', command=self.testWin, width=25, height=1).pack(pady=(0, 10))
        
        # Back to Menu Button
        tk.Button(self.action_panel, text="Back to Menu", font=('Segoe UI', 9), bg='#95A5A6', fg='white', command=self.createMainMenu, width=25).pack(pady=(0, 20))
    
        # Initial update of action panel
        self.updateActionPanel()
    
    def updateActionPanel(self):
        """Updates the action panel with current player info and property action buttons"""
        
        current_player = self.players[self.current_player_index]
        
        # Update player info labels
        self.current_player_label.config(text=current_player.name, fg=current_player.color)
        self.player_balance_label.config(text=f"Balance: ${current_player.balance}")
        if self.tiles[current_player.location]['type'] == 'property':
            position_name = self.getPropertyById(self.tiles[current_player.location]['property_id']).name
        elif self.tiles[current_player.location]['type'] == 'corner' and self.tiles[current_player.location]['position'] == 10:
            if current_player.in_jail:
                position_name = "In Jail"
            else:
                position_name = "Just Visiting"
        else:
            position_name = self.tiles[current_player.location]['name']
        self.player_position_label.config(text=f"Position: {position_name}")
        
        # Update dice Button
        if current_player.has_rolled:
            self.dice_btn.config(state='disabled', bg='#CCCCCC', fg='#666666')
        else:
            self.dice_btn.config(state='normal', bg='#4CAF50', fg='white')
        
        # Update property card display
        if hasattr(self, 'property_card_container'):
            # Clear the property card container
            for widget in self.property_card_container.winfo_children():
                widget.destroy()
            
            if current_player.selected_property:
                prop = current_player.selected_property
                # Try to load the property image
                if PIL_AVAILABLE and prop.type in ['property', 'railroad', 'utility']:
                    try:
                        # Use mortgaged version if property is mortgaged
                        if prop.mortgaged:
                            img_path = f"cards/mortgaged/{prop.id}.png"
                        else:
                            img_path = f"cards/property/{prop.id}.png"
                        
                        img = Image.open(img_path)
                        img = img.resize((200, 300), Image.Resampling.LANCZOS)
                        photo = ImageTk.PhotoImage(img)
                        
                        img_label = tk.Label(self.property_card_container, image=photo, bg='white')
                        img_label.image = photo
                        img_label.pack()
                    except Exception as e:
                        # If image can't be loaded, show property text
                        self._show_property_text_in_panel(prop)
                else:
                    # PIL not available or not a property/railroad/utility type, show property details
                    self._show_property_text_in_panel(prop)
            else:
                # No property selected - show placeholder
                self.property_card_label = tk.Label(self.property_card_container, text="Click a property\nto view its card", font=('Segoe UI', 10, 'italic'), bg='white', fg='#999999')
                self.property_card_label.pack(expand=True)
        
        current_player = self.players[self.current_player_index]
        
        if hasattr(self, 'buy_property_btn'):
            if current_player.selected_property is None or current_player.location != current_player.selected_property.location or current_player.selected_property.owner != None or current_player.balance < current_player.selected_property.price:
                # No property selected, not on property, or property already owned - disable buy
                self.buy_property_btn.config(state='disabled', bg='#CCCCCC', fg='#666666')
            else:
                # Player is on unowned property and can afford it - enable buy
                self.buy_property_btn.config(state='normal', bg='#2196F3', fg='white')
        
        # Update property action buttons
        if hasattr(self, 'buy_building_btn') and hasattr(self, 'sell_building_btn'):
            if current_player.selected_property and current_player.selected_property.type == 'property' and current_player.selected_property.color:
                prop = current_player.selected_property
                buildings = prop.houses_and_hotels
                
                # Check if the current player owns this property
                if prop.owner != current_player:
                    # Player doesn't own the property - disable all building actions
                    self.buy_building_btn.config(state='disabled', text='Buy Building', bg='#CCCCCC', fg='#666666')
                    self.sell_building_btn.config(state='disabled', text='Sell Building', bg='#CCCCCC', fg='#666666')
                else:
                    # Player owns the property - check monopoly status
                    color_group = [p for p in self.properties if p.color == prop.color]
                    if not all(p.owner == current_player for p in color_group):
                        self.buy_building_btn.config(state='disabled', text='Buy House', bg='#CCCCCC', fg='#666666')
                        # Still allow selling buildings even without monopoly (but only if they own it)
                        if buildings == 0:
                            self.sell_building_btn.config(state='disabled', text='Sell Building', bg='#CCCCCC', fg='#666666')
                        elif buildings == 5:
                            self.sell_building_btn.config(state='normal', text='Sell Hotel', bg='#FFC107', fg='black')
                        else:
                            self.sell_building_btn.config(state='normal', text='Sell House', bg='#FFC107', fg='black')
                    else:
                        # Player has monopoly - enable building/selling as appropriate
                        # Update Buy Building button
                        if buildings < 4:
                            # Can buy houses (0-3 houses) - check if player can afford it
                            if current_player.balance >= prop.house_hotel_cost:
                                self.buy_building_btn.config(state='normal', text='Buy House', bg='#FF9800', fg='white')
                            else:
                                self.buy_building_btn.config(state='disabled', text='Buy House', bg='#CCCCCC', fg='#666666')
                        elif buildings == 4:
                            # Can upgrade to hotel - check if player can afford it
                            if current_player.balance >= prop.house_hotel_cost:
                                self.buy_building_btn.config(state='normal', text='Buy Hotel', bg='#FF9800', fg='white')
                            else:
                                self.buy_building_btn.config(state='disabled', text='Buy Hotel', bg='#CCCCCC', fg='#666666')
                        else:
                            # Already has hotel (5), can't buy more
                            self.buy_building_btn.config(state='disabled', text='Buy Building', bg='#CCCCCC', fg='#666666')
                        
                        # Update Sell Building button
                        if buildings == 0:
                            # No buildings to sell
                            self.sell_building_btn.config(state='disabled', text='Sell Building', bg='#CCCCCC', fg='#666666')
                        elif buildings == 5:
                            # Has hotel
                            self.sell_building_btn.config(state='normal', text='Sell Hotel', bg='#FFC107', fg='black')
                        else:
                            # Has houses (1-4)
                            self.sell_building_btn.config(state='normal', text='Sell House', bg='#FFC107', fg='black')
            else:
                # No property selected or not a buildable property - disable both buttons
                self.buy_building_btn.config(state='disabled', text='Buy Building', bg='#CCCCCC', fg='#666666')
                self.sell_building_btn.config(state='disabled', text='Sell Building', bg='#CCCCCC', fg='#666666')
        
        # Update mortgage buttons
        if hasattr(self, 'mortgage_btn') and hasattr(self, 'unmortgage_btn'):
            if current_player.selected_property is None or current_player.selected_property.owner != current_player:
                # No property selected or player doesn't own it - disable both
                self.mortgage_btn.config(state='disabled', bg='#CCCCCC', fg='#666666')
                self.unmortgage_btn.config(state='disabled', bg='#CCCCCC', fg='#666666')
            elif current_player.selected_property.houses_and_hotels > 0:
                # Property has buildings - must sell buildings first, disable mortgage
                self.mortgage_btn.config(state='disabled', bg='#CCCCCC', fg='#666666')
                # Can still unmortgage even with buildings (though you can't have both)
                if current_player.selected_property.mortgaged:
                    self.unmortgage_btn.config(state='normal', bg="#583891", fg='white')
                else:
                    self.unmortgage_btn.config(state='disabled', bg='#CCCCCC', fg='#666666')
            elif current_player.selected_property.mortgaged:
                # Property is mortgaged - enable unmortgage, disable mortgage
                self.mortgage_btn.config(state='disabled', bg='#CCCCCC', fg='#666666')
                self.unmortgage_btn.config(state='normal', bg="#583891", fg='white')
            else:
                # Property is not mortgaged and has no buildings - enable mortgage, disable unmortgage
                self.mortgage_btn.config(state='normal', bg='#9C27B0', fg='white')
                self.unmortgage_btn.config(state='disabled', bg='#CCCCCC', fg='#666666')
        
        # Update Get Out of Jail button
        if hasattr(self, 'jail_btn'):
            if current_player.in_jail:
                # Player is in jail - enable button
                if current_player.get_out_of_jail_card:
                    # Has card - show "Use Card (Free)"
                    self.jail_btn.config(state='normal', text='Use Get Out of Jail Card (Free)', bg='#FFA500', fg='white')
                else:
                    # No card - show "Pay $50"
                    self.jail_btn.config(state='normal', text='Pay $50 to Get Out', bg='#FFA500', fg='white')
            else:
                # Not in jail - disable
                self.jail_btn.config(state='disabled', text='Get Out of Jail', bg='#CCCCCC', fg='#666666')
    
    def rollDice(self):
        """Roll dice for the current player"""
        current_player = self.players[self.current_player_index]
        
        # Check if player has been in jail for 3 turns
        if current_player.in_jail and current_player.jail_turns >= 3:
            # Must pay $50 to get out
            if current_player.balance >= 50:
                current_player.pay(50)
                current_player.in_jail = False
                current_player.jail_turns = 0
                self.showMessage("Jail Time's Up", f"{current_player.name} has been in jail for 3 turns and must pay $50 to get out.")
            else:
                # Player doesn't have enough money - set debt to bank
                current_player.pay(50)
                current_player.debt_amount = abs(current_player.balance)
                current_player.balance = 0
                current_player.creditor = None  # Owes bank
                current_player.in_jail = False
                current_player.jail_turns = 0
                
                # Check if they can pay by selling/mortgaging
                if self.canPayDebt(current_player):
                    self.showMessage(
                        "Insufficient Funds",
                        f"{current_player.name} has been in jail for 3 turns and must pay $50!\n\nYou must sell buildings and/or mortgage properties to pay ${current_player.debt_amount}.\n\nYou cannot end your turn until the debt is paid."
                    )
                else:
                    # Player is bankrupt
                    self.handleBankruptcy(current_player)
                    return
            
            self.updateBoard()
            self.updateActionPanel()
            return
        
        # Roll the dice
        dice1 = random.randint(1, 6)
        dice2 = random.randint(1, 6)
        total = dice1 + dice2
        message = ""

        # Check if doubles were rolled
        if dice1 == dice2:
            current_player.doubles_count += 1
            current_player.doubles_amount += total
            
            if current_player.doubles_count == 3:
                message = f"You rolled double {dice1}'s! \nThat's 3 doubles in a row - you're being sent to jail!"
                current_player.moveToJail()
                current_player.doubles_count = 0
                current_player.doubles_amount = 0
            elif current_player.in_jail:
                message = f"You rolled double {dice1}'s! \nYou're out of jail and can move {total} spaces."
                current_player.in_jail = False
                current_player.jail_turns = 0
                current_player.doubles_count = 0
                current_player.doubles_amount = 0
                current_player.move(total)
                self.handleLanding(dice_roll=total)
            else:
                message = f"You rolled double {dice1}'s (Total: {current_player.doubles_amount})! Roll again."
                current_player.move(total)

        else:
            # Not doubles
            current_player.doubles_count = 0
            current_player.has_rolled = True
            
            if current_player.in_jail:
                current_player.jail_turns += 1
                message = f"You rolled {dice1} and {dice2}. \nStill in jail (didn't roll doubles). Turn {current_player.jail_turns}/3 in jail."
            else:
                message = f"You rolled {dice1} and {dice2} (Total: {current_player.doubles_amount + total})"
                current_player.move(total)
                self.handleLanding(dice_roll=total)
                
            current_player.doubles_amount = 0
        
        # Display the message in the dice result label
        self.dice_result_label.config(text=message, fg='#333333')

        # Update the board and action panel
        self.updateBoard()
        self.updateActionPanel()
    
    def handleLanding(self, rent_multiplier=1, rent_override=None, dice_roll=None):
        """Handle the logic when a player lands on a tile
        
        Args:
            rent_multiplier: Multiplier for rent (used by certain cards)
            rent_override: Override rent amount (used by certain cards)
            dice_roll: The dice roll total (needed for utility rent calculation)
        """
        current_player = self.players[self.current_player_index]
        tile = self.tiles[current_player.location]
        
        # Handle landing on tax tiles
        if tile['type'] == 'tax':
            tax_amount = tile['amount']
            
            if current_player.balance >= tax_amount:
                # Can pay tax
                current_player.pay(tax_amount)
                self.showMessage("Tax Paid", f"{current_player.name} paid ${tax_amount} in {tile['name']}.")
            else:
                # Cannot pay tax - set debt to bank
                current_player.pay(tax_amount)
                current_player.debt_amount = abs(current_player.balance)
                current_player.balance = 0
                current_player.creditor = None
                
                self.showMessage(
                    "Insufficient Funds",
                    f"{current_player.name} cannot pay ${tax_amount} in taxes!\n\nYou must sell buildings and/or mortgage properties to pay ${current_player.debt_amount}.\n\nYou cannot end your turn until the debt is paid."
                )
            
            self.updateActionPanel()
            return
        
        # Handle landing on owned properties
        elif tile['type'] == 'property':
            prop = self.getPropertyById(tile['property_id'])
            
            # Set the property as selected so player can see it
            current_player.selected_property = prop
            self.updateActionPanel()
            self.updateBoard()
            
            # If property is owned by another player and not mortgaged
            if prop.owner and prop.owner != current_player and not prop.mortgaged:
                # Calculate rent
                if rent_override:
                    rent_amount = rent_override
                else:
                    # For utilities, pass the dice roll; otherwise use default
                    if prop.type == 'utility' and dice_roll:
                        rent_amount = self.calculateRent(prop, dice_roll) * rent_multiplier
                    else:
                        rent_amount = self.calculateRent(prop) * rent_multiplier
                
                if current_player.balance >= rent_amount:
                    # Can pay rent
                    current_player.pay(rent_amount, prop.owner)
                    self.showMessage(
                        "Rent Paid",
                        f"{current_player.name} paid ${rent_amount} in rent to {prop.owner.name} for landing on {prop.name}."
                    )
                else:
                    # Cannot pay rent - set debt to property owner
                    current_player.pay(rent_amount, prop.owner)
                    current_player.debt_amount = abs(current_player.balance)
                    current_player.balance = 0
                    current_player.creditor = prop.owner
                    
                    self.showMessage(
                        "Insufficient Funds",
                        f"{current_player.name} cannot pay ${rent_amount} in rent to {prop.owner.name}!\n\nYou must sell buildings and/or mortgage properties to pay ${current_player.debt_amount}.\n\nYou cannot end your turn until the debt is paid."
                    )
                
                self.updateActionPanel()
                
        elif tile['type'] == 'corner':
            # Handle landing on Jail
            if tile['position'] == 30:
                current_player.moveToJail()
                self.showMessage("Jail", f"{current_player.name} is now in jail.")
                
        elif tile['type'] == 'chance' or tile['type'] == 'community_chest':
            # Handle drawing a card from the respective deck
            if tile['type'] == 'chance':
                card = self.chance_cards.pop(0)
                self.showMessage("Chance Card", f"{current_player.name} drew a Chance card:\n\n{card.text}")
                self.chance_cards.append(card)  # Add back to the end of the deck
                
            elif tile['type'] == 'community_chest':
                card = self.community_chest_cards.pop(0)
                self.showMessage("Community Chest Card", f"{current_player.name} drew a Community Chest card:\n\n{card.text}")
                self.community_chest_cards.append(card)  # Add back to the end of the deck
            
            # Run the card's action
            card.runAction(current_player, self)
            
            self.updateActionPanel()
    
    def calculateRent(self, prop: Property, dice_roll: int = 7) -> int:
        """Calculate the rent for a property based on its type and state"""
        return prop.calculateRent(self.properties, dice_roll)
        
    def buyProperty(self):
        """Buy the property the player is on"""
        
        current_player = self.players[self.current_player_index]
        prop = self.getPropertyById(self.tiles[current_player.location]['property_id'])
        
        if prop.owner:
            self.showMessage("Error", f"{prop.name} is already owned by {prop.owner.name}.")
            return
        
        if current_player.balance < prop.price:
            self.showMessage("Error", f"You don't have enough money to buy {prop.name}.")
            return
        
        # Confirm purchase
        result = self.showConfirmation(
            "Buy Property",
            f"Buy {prop.name} for ${prop.price}?\n\n(Your balance: ${current_player.balance}\n\n(Projected balance: ${current_player.balance - prop.price})"
        )
        
        if result:
            # Buy the property
            current_player.pay(prop.price)
            current_player.properties.append(prop)
            prop.owner = current_player
            
            # Update UI
            self.updateBoard()
            self.updateActionPanel()
        
    def buyBuilding(self):
        """Buy a house or hotel on the selected property."""
        current_player = self.players[self.current_player_index]
        if current_player.selected_property is None:
            self.showMessage("Error", "No property selected.")
            return
        
        prop = current_player.selected_property
        
        # Check if the current player owns this property
        if prop.owner != current_player:
            self.showMessage("Error", f"You don't own {prop.name}.")
            return
        
        if prop.type != 'property' or not prop.color:
            self.showMessage("Error", "You can only build on colored properties.")
            return
        
        # Check if player owns all properties in the color group (monopoly)
        color_group = [p for p in self.properties if p.color == prop.color]
        if not all(p.owner == current_player for p in color_group):
            self.showMessage("Error", f"You must own all {prop.color} properties before building.")
            return
        
        if prop.mortgaged:
            self.showMessage("Error", f"{prop.name} is mortgaged. You must unmortgage it first.")
            return
        
        if prop.houses_and_hotels >= 5:
            self.showMessage("Error", f"{prop.name} already has a hotel (maximum building).")
            return
        
        if not prop.house_hotel_cost or prop.house_hotel_cost == 0:
            self.showMessage("Error", "Building cost not available for this property.")
            return
        
        building_cost = prop.house_hotel_cost
        building_type = "house" if prop.houses_and_hotels < 4 else "hotel"
        
        if current_player.balance < building_cost:
            self.showMessage("Error", f"You don't have enough money to buy a {building_type}.\n\nRequired: ${building_cost}\nYour balance: ${current_player.balance}")
            return
        
        # Confirm purchase
        result = self.showConfirmation(
            f"Buy {building_type.capitalize()}",
            f"Buy {building_type} on {prop.name} for ${building_cost}?\n\n(Your balance: ${current_player.balance})\n\n(Projected balance: ${current_player.balance - building_cost})"
        )
        
        if result:
            # Build the house or hotel
            current_player.pay(building_cost)
            prop.houses_and_hotels += 1
            
            self.updateBoard()
            self.updateActionPanel()
            self.showMessage("Success", f"Successfully bought {building_type} on {prop.name} for ${building_cost}")
    
    def sellBuilding(self):
        """Sell a house or hotel from the selected property."""
        current_player = self.players[self.current_player_index]
        if current_player.selected_property is None:
            self.showMessage("Error", "No property selected.")
            return
        
        prop = current_player.selected_property
        
        # Check if the current player owns this property
        if prop.owner != current_player:
            self.showMessage("Error", f"You don't own {prop.name}.")
            return
        
        if prop.houses_and_hotels == 0:
            self.showMessage("Error", f"{prop.name} has no buildings to sell.")
            return
        
        if not prop.house_hotel_cost:
            self.showMessage("Error", "Building cost not available for this property.")
            return
        
        sale_price = prop.house_hotel_cost // 2
        building_type = "hotel" if prop.houses_and_hotels == 5 else "house"
        
        # Confirm sale
        result = self.showConfirmation(
            f"Sell {building_type.capitalize()}",
            f"Sell {building_type} from {prop.name} for ${sale_price}?\n\n(Original cost: ${prop.house_hotel_cost})"
        )
        
        if result:
            # Remove building and collect money
            prop.houses_and_hotels -= 1
            current_player.collect(sale_price)
            
            # Check if player has debt - automatically apply money to debt
            if current_player.debt_amount > 0:
                if sale_price >= current_player.debt_amount:
                    # Paid off debt completely
                    paid_amount = current_player.debt_amount
                    current_player.balance -= current_player.debt_amount
                    
                    # Transfer to creditor
                    if current_player.creditor:
                        current_player.creditor.collect(paid_amount)
                    
                    current_player.debt_amount = 0
                    current_player.creditor = None
                    
                    self.showMessage("Debt Paid", f"Sold {building_type} from {prop.name} for ${sale_price}.\n\nDebt of ${paid_amount} has been paid!")
                else:
                    # Partial payment
                    current_player.balance -= sale_price
                    
                    # Transfer to creditor
                    if current_player.creditor:
                        current_player.creditor.collect(sale_price)
                    
                    current_player.debt_amount -= sale_price
                    
                    self.showMessage("Partial Payment", f"Sold {building_type} from {prop.name} for ${sale_price}.\n\nRemaining debt: ${current_player.debt_amount}")
            else:
                self.showMessage("Success", f"Sold {building_type} from {prop.name} for ${sale_price}")
            
            self.updateBoard()
            self.updateActionPanel()
        
    def mortgageProperty(self):
        """Mortgage a property"""
        current_player = self.players[self.current_player_index]
        
        if current_player.selected_property is None:
            self.showMessage("Error", "No property selected.")
            return
        
        prop = current_player.selected_property
        
        # Check if the current player owns this property
        if prop.owner != current_player:
            self.showMessage("Error", f"You don't own {prop.name}.")
            return
        
        if prop.mortgaged:
            self.showMessage("Error", f"{prop.name} is already mortgaged.")
            return
        
        if prop.houses_and_hotels > 0:
            self.showMessage("Error", f"You must sell all buildings on {prop.name} before mortgaging.")
            return
        
        mortgage_value = prop.price // 2
        
        # Confirm mortgage
        result = self.showConfirmation(
            "Mortgage Property",
            f"Mortgage {prop.name} for ${mortgage_value}?\n\nYou'll need to pay ${int(mortgage_value * 1.1)} to unmortgage it later."
        )
        
        if result:
            # Mortgage the property
            prop.mortgaged = True
            current_player.collect(mortgage_value)
            
            # Check if player has debt - automatically apply money to debt
            if current_player.debt_amount > 0:
                if mortgage_value >= current_player.debt_amount:
                    # Paid off debt completely
                    paid_amount = current_player.debt_amount
                    current_player.balance -= current_player.debt_amount
                    
                    # Transfer to creditor
                    if current_player.creditor:
                        current_player.creditor.collect(paid_amount)
                    
                    current_player.debt_amount = 0
                    current_player.creditor = None
                    
                    self.showMessage("Debt Paid", f"Mortgaged {prop.name} for ${mortgage_value}.\n\nDebt of ${paid_amount} has been paid!")
                else:
                    # Partial payment
                    current_player.balance -= mortgage_value
                    
                    # Transfer to creditor
                    if current_player.creditor:
                        current_player.creditor.collect(mortgage_value)
                    
                    current_player.debt_amount -= mortgage_value
                    
                    self.showMessage("Partial Payment", f"Mortgaged {prop.name} for ${mortgage_value}.\n\nRemaining debt: ${current_player.debt_amount}")
            else:
                self.showMessage("Success", f"Mortgaged {prop.name} for ${mortgage_value}")
            
            self.updateBoard()
            self.updateActionPanel()
        
    def unmortgageProperty(self):
        """Unmortgage a property"""
        current_player = self.players[self.current_player_index]
        
        if current_player.selected_property is None:
            self.showMessage("Error", "No property selected.")
            return
        
        prop = current_player.selected_property
        
        # Check if the current player owns this property
        if prop.owner != current_player:
            self.showMessage("Error", f"You don't own {prop.name}.")
            return
        
        if not prop.mortgaged:
            self.showMessage("Error", f"{prop.name} is not mortgaged.")
            return
        
        unmortgage_cost = int((prop.price // 2) * 1.1)
        
        if current_player.balance < unmortgage_cost:
            self.showMessage("Error", f"You don't have enough money to unmortgage {prop.name}.\n\nRequired: ${unmortgage_cost}\nYour balance: ${current_player.balance}")
            return
        
        # Confirm unmortgage
        result = self.showConfirmation(
            "Unmortgage Property",
            f"Unmortgage {prop.name} for ${unmortgage_cost}?\n\n(Includes 10% interest)\n(Your balance: ${current_player.balance})"
        )
        
        if result:
            # Unmortgage the property
            prop.mortgaged = False
            current_player.pay(unmortgage_cost)
            
            self.updateBoard()
            self.updateActionPanel()
            self.showMessage("Success", f"Unmortgaged {prop.name} for ${unmortgage_cost}")
    
    def getOutOfJail(self):
        """Get out of jail by using a card or paying $50"""
        current_player = self.players[self.current_player_index]
        
        if not current_player.in_jail:
            self.showMessage("Error", "You are not in jail.")
            return
        
        # Check if player has a Get Out of Jail Free card
        if current_player.get_out_of_jail_card:
            # Use the card
            result = self.showConfirmation(
                "Use Get Out of Jail Free Card?",
                f"{current_player.name}, would you like to use your Get Out of Jail Free card?"
            )
            
            if result:
                current_player.get_out_of_jail_card = False
                current_player.in_jail = False
                current_player.jail_turns = 0
                current_player.doubles_count = 0
                
                self.updateBoard()
                self.updateActionPanel()
                self.showMessage("Freedom!", f"{current_player.name} used a Get Out of Jail Free card and is now free!")
        else:
            # Pay $50 to get out
            if current_player.balance >= 50:
                result = self.showConfirmation(
                    "Pay to Get Out of Jail?",
                    f"{current_player.name}, pay $50 to get out of jail?\n\nYour balance: ${current_player.balance}\nProjected balance: ${current_player.balance - 50}"
                )
                
                if result:
                    current_player.pay(50)
                    current_player.in_jail = False
                    current_player.jail_turns = 0
                    current_player.doubles_count = 0
                    
                    self.updateBoard()
                    self.updateActionPanel()
                    self.showMessage("Freedom!", f"{current_player.name} paid $50 and is now free from jail!")
            else:
                self.showMessage(
                    "Insufficient Funds",
                    f"You don't have enough money to pay $50 to get out of jail.\n\nYour balance: ${current_player.balance}\nRequired: $50\n\nYou can try rolling doubles or wait until you have enough money."
                )
    
    def showMessage(self, title, message):
        """Display a simple message dialog"""
        messagebox.showinfo(title, message)
    
    def showConfirmation(self, title, message):
        """Display a confirmation dialog and return True if user confirms"""
        return messagebox.askyesno(title, message)
    
    def testWin(self):
        """TEST FUNCTION: Immediately trigger victory for current player"""
        current_player = self.players[self.current_player_index]
        
        # Remove all other players to simulate victory
        self.players = [current_player]
        
        # Show victory screen
        self.showVictoryScreen(current_player)
        
    def canPayDebt(self, player: Player) -> bool:
        """Check if player can pay their debt by selling buildings or mortgaging properties.
        
        Args:
            player: The player to check
            
        Returns:
            bool: True if player has unmortgaged properties or buildings to sell
        """
        # Check if player has any buildings to sell
        for prop in player.properties:
            if prop.houses_and_hotels > 0:
                return True
        
        # Check if player has any unmortgaged properties
        for prop in player.properties:
            if not prop.mortgaged:
                return True
        
        return False
    
    def handleBankruptcy(self, player: Player):
        """Handle player bankruptcy - transfer all assets to creditor and remove from game.
        
        Args:
            player: The bankrupt player
        """
        creditor = player.creditor
        
        # Build bankruptcy message
        if creditor:
            message = f"{player.name} is bankrupt!\n\n{creditor.name} receives all of {player.name}'s assets:\n\n"
        else:
            message = f"{player.name} is bankrupt!\n\nAll properties return to the bank.\n\n"
        
        # Transfer properties to creditor
        properties_transferred = []
        for prop in player.properties[:]:
            properties_transferred.append(prop.name)
            
            if creditor:
                # Transfer to creditor - keep mortgage status and buildings
                player.properties.remove(prop)
                creditor.properties.append(prop)
                prop.owner = creditor
            else:
                # Return to bank - clear mortgage and buildings
                player.properties.remove(prop)
                prop.owner = None
                prop.mortgaged = False
                prop.houses_and_hotels = 0
        
        if properties_transferred:
            message += "Properties: " + ", ".join(properties_transferred) + "\n"
        
        # Transfer Get Out of Jail Free card
        if player.get_out_of_jail_card:
            if creditor:
                creditor.get_out_of_jail_card = True
                message += "\nGet Out of Jail Free card transferred!\n"
            player.get_out_of_jail_card = False
        
        # Transfer any positive balance to creditor
        if player.balance > 0 and creditor:
            creditor.collect(player.balance)
            message += f"\nCash: ${player.balance}"
            player.balance = 0
        
        # Remove player from game
        self.players.remove(player)
        
        # Adjust current player index if needed
        if self.current_player_index >= len(self.players):
            self.current_player_index = 0
        
        # Check if game is over (only one player left)
        if len(self.players) == 1:
            winner = self.players[0]
            self.showMessage("Bankruptcy", message)
            # Show victory screen
            self.showVictoryScreen(winner)
        else:
            self.showMessage("Bankruptcy", message)
        
        # Update UI
        self.updateBoard()
        self.updateActionPanel()
    
    def endTurn(self):
        """End the current player's turn"""
        current_player = self.players[self.current_player_index]
        
        # Check if player has debt - cannot end turn until debt is paid
        if current_player.debt_amount > 0:
            # Check if player can pay by selling/mortgaging
            if self.canPayDebt(current_player):
                self.showMessage(
                    "Cannot End Turn",
                    f"You owe ${current_player.debt_amount}!\n\nYou must sell buildings and/or mortgage properties to pay your debt before ending your turn.\n\nCurrent balance: ${current_player.balance}\nAmount owed: ${current_player.debt_amount}"
                )
                return
            else:
                # Player is bankrupt - has no way to pay
                self.handleBankruptcy(current_player)
                return
        
        # Normal end turn
        current_player.selected_property = None
        current_player.debt_amount = 0
        current_player.creditor = None
        current_player.has_rolled = False
        
        self.current_player_index = (self.current_player_index + 1) % len(self.players)
        current_player = self.players[self.current_player_index]
        self.updateActionPanel()
        
        # updateActionPanel will handle property card display
        self.updateBoard()
        
        self.dice_result_label.config(text="")
    
    def convertPositionToCoordinates(self, position):
        """Converts a board position to x, y coordinates for the GUI.

        Args:
            position (int): The board position (0-39).
        Returns:
            tuple: (x, y) coordinates for the GUI.
        """
        
        if position < 10:
            return (10 - position, 10)
        elif position < 20:
            return (0, 10 - (position - 10))
        elif position < 30:
            return (position - 20, 0)
        else:
            return (10, position - 30)
        
    def getPropertyById(self, property_id):
        """Retrieves a property by its ID.

        Args:
            property_id (int): The ID of the property to retrieve.
        Returns:
            Property: The property with the given ID, or None if not found.
        """
        
        for property in self.properties:
            if property.id == property_id:
                return property
        return None
    
    def _selectProperty(self, property):
        """Helper to select a property and update the action panel.
        
        Args:
            property (Property): The property to select.
        """
        current_player = self.players[self.current_player_index]
        current_player.selected_property = property
        self.updateActionPanel()
        self.updateBoard()
    
    def _show_property_text_in_panel(self, property):
        """Helper method to show property details as text in the action panel when image is not available.
        
        Args:
            property (Property): The property to display.
        """
        # Color indicator for street properties
        if property.type == 'property' and property.color:
            color_bar = tk.Frame(
                self.property_card_container,
                bg=self.color_map.get(property.color, 'white'),
                height=20
            )
            color_bar.pack(fill='x')
        
        # Property name
        name_label = tk.Label(
            self.property_card_container,
            text=property.name,
            font=("Arial", 12, "bold"),
            bg='white',
            wraplength=220
        )
        name_label.pack(pady=10)
        
        # Price
        price_label = tk.Label(
            self.property_card_container,
            text=f"${property.price}",
            font=("Arial", 11, "bold"),
            bg='white'
        )
        price_label.pack(pady=5)
        
        # Rent info (simplified)
        if property.type == 'property':
            rent_text = f"Rent: ${property.rent[0]}"
            if property.mortgaged:
                rent_text = "MORTGAGED"
            rent_label = tk.Label(
                self.property_card_container,
                text=rent_text,
                font=("Arial", 9),
                bg='white'
            )
            rent_label.pack(pady=5)
    
if __name__ == "__main__":
    game = Monopoly("./monopoly_cards.json")
    game.start()