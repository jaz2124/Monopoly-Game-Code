# Py-Monopoly 🎲

A fully-featured Monopoly game implementation built with Python and Tkinter, featuring a graphical user interface, complete game mechanics, and property card overlays.

## ⚠️ Important: Required Dependencies

**This project requires the Pillow library to be installed for property card image display.**

### Installing Pillow

Before running the game, you **MUST** install Pillow using pip:

```bash
pip install Pillow
```

**Without Pillow installed, the property card overlay feature will not work!** The game checks for Pillow availability at runtime and disables image features if it's not found.

## Features

- 🎮 Full Monopoly game implementation with classic rules
- 🏠 Property management (buying, selling, mortgaging, building houses/hotels)
- 🎴 Chance and Community Chest cards
- 👥 Support for 2-6 players
- 🖼️ Property card overlays with images (requires Pillow)
- 💰 Complete financial system (rent, taxes, payments)
- 🎲 Dice rolling mechanics with doubles detection
- 🚔 Jail system with Get Out of Jail Free cards
- 🎨 Color-coded player tokens
- 📊 Real-time balance and property tracking

## Requirements

- Python 3.6 or higher
- tkinter (usually included with Python)
- **Pillow (PIL Fork)** - Required for property card images

## Installation

1. Clone this repository:
```bash
git clone https://github.com/SoulThread2597/Py-Monopoly.git
cd Py-Monopoly
```

2. **Install Pillow (REQUIRED):**
```bash
pip install Pillow
```

3. Ensure you have the required files:
   - `monopoly.py` - Main game file
   - `monopoly_cards.json` - Property and card data
   - `cards/` directory - Contains property and mortgaged card images

## Usage

Run the game with:

```bash
python monopoly.py
```

### Game Setup

1. Enter the number of players (2-6)
2. For each player, enter their name and select a color
3. Click "Start Game" to begin

### How to Play

- **Roll Dice**: Click the "Roll Dice" button to move your player
- **Buy Property**: When landing on an unowned property, click "Buy" to purchase it
- **Manage Properties**: Select your properties from the sidebar to:
  - Build houses/hotels
  - Mortgage/unmortgage properties
  - View property cards (click on property tile)
- **End Turn**: Click "End Turn" after completing your actions
- **Jail**: Pay $50, use a Get Out of Jail Free card, or roll doubles to escape

## Game Rules

The game follows standard Monopoly rules:

- Pass GO to collect $200
- Land on properties to buy them or pay rent
- Build houses and hotels when you own all properties of a color group
- Pay taxes on Income Tax and Luxury Tax spaces
- Draw Chance or Community Chest cards for special actions
- Go to Jail if you roll doubles three times in a row
- Players are eliminated when they go bankrupt
- Last player remaining wins!

## Project Structure

```
Py-Monopoly/
├── monopoly.py              # Main game logic and GUI
├── monopoly_cards.json      # Property, Chance, and Community Chest data
├── cards/
│   ├── property/           # Property card images
│   └── mortgaged/          # Mortgaged property card images
├── LICENSE
└── README.md
```

## Classes

- **Player**: Manages player state (balance, properties, location)
- **Property**: Handles property data and rent calculations
- **Card**: Manages Chance and Community Chest cards
- **Monopoly**: Main game controller with GUI and game logic

## Technical Details

- Uses JSON for property and card data storage
- Tkinter Canvas for game board rendering
- PIL/Pillow for image handling in property overlays
- Event-driven architecture for game flow
- Modular class-based design

## License

This project is available under the MIT License. See LICENSE file for details.

## Credits

Created by Python Blocks
- SoulThread (https://github.com/SoulThread2597)

Based on the classic Monopoly board game by Hasbro.